const { Pinecone } = require('@pinecone-database/pinecone');
const OpenAI = require('openai');

// Environment variables (you'd set these in your Lambda or API)
const PINECONE_API_KEY = process.env.PINECONE_API_KEY;
const PINECONE_INDEX_NAME = process.env.PINECONE_INDEX_NAME || 'beya-context';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
const pinecone = new Pinecone({ apiKey: PINECONE_API_KEY });
const index = pinecone.index(PINECONE_INDEX_NAME);

/**
 * Semantic search function
 * @param {string} query - The search query
 * @param {Object} filters - Optional metadata filters
 * @param {number} topK - Number of results to return
 */
async function semanticSearch(query, filters = {}, topK = 5) {
  try {
    // Step 1: Convert query to embedding
    console.log(`🔍 Searching for: "${query}"`);
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: query,
    });
    
    const queryEmbedding = embeddingResponse.data[0].embedding;
    
    // Step 2: Search Pinecone
    const searchRequest = {
      vector: queryEmbedding,
      topK,
      includeMetadata: true,
      includeValues: false, // We don't need the actual embeddings back
    };
    
    // Add filters if provided
    if (Object.keys(filters).length > 0) {
      searchRequest.filter = filters;
    }
    
    const searchResults = await index.query(searchRequest);
    
    // Step 3: Format results
    const formattedResults = searchResults.matches.map(match => ({
      id: match.id,
      score: match.score,
      threadId: match.metadata.threadId,
      eventType: match.metadata.eventType,
      timestamp: match.metadata.timestamp,
      sentiment: match.metadata.sentiment,
      sentimentConfidence: match.metadata.sentimentConfidence,
      chunkIndex: match.metadata.chunkIndex,
      chunkCount: match.metadata.chunkCount,
    }));
    
    console.log(`📊 Found ${formattedResults.length} relevant results:`);
    formattedResults.forEach((result, idx) => {
      console.log(`${idx + 1}. Score: ${result.score.toFixed(3)} | Thread: ${result.threadId} | Sentiment: ${result.sentiment}`);
    });
    
    return {
      query,
      results: formattedResults,
      matches: searchResults.matches, // Full matches with metadata
    };
    
  } catch (error) {
    console.error('❌ Semantic search failed:', error);
    throw error;
  }
}

/**
 * Generate AI response using search results as context
 * @param {string} userQuery - The user's question
 * @param {Array} searchResults - Results from semantic search
 */
async function generateContextualResponse(userQuery, searchResults) {
  try {
    // Build context from search results
    const contextChunks = searchResults.matches
      .slice(0, 3) // Use top 3 most relevant results
      .map((match, idx) => {
        const metadata = match.metadata;
        return `Context ${idx + 1} (Relevance: ${match.score.toFixed(2)}):
Thread: ${metadata.threadId}
Timestamp: ${metadata.timestamp}
Sentiment: ${metadata.sentiment} (${(metadata.sentimentConfidence * 100).toFixed(1)}% confidence)
Event Type: ${metadata.eventType}
---`;
      })
      .join('\n');
    
    const prompt = `You are a helpful customer service AI assistant. Based on the conversation context below, provide a helpful and empathetic response to the user's query.

CONVERSATION CONTEXT:
${contextChunks}

USER QUERY: ${userQuery}

Please provide a response that:
1. Takes into account the conversation history and sentiment
2. Is empathetic and appropriate to the context
3. Addresses the user's specific question
4. Maintains a professional but friendly tone

RESPONSE:`;

    console.log('🤖 Generating AI response...');
    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 300,
      temperature: 0.7,
    });
    
    const aiResponse = completion.choices[0].message.content;
    console.log('✅ AI Response generated');
    
    return {
      userQuery,
      aiResponse,
      contextUsed: searchResults.results.slice(0, 3),
    };
    
  } catch (error) {
    console.error('❌ AI response generation failed:', error);
    throw error;
  }
}

/**
 * Complete semantic search + AI response pipeline
 */
async function queryWithAI(userQuery, filters = {}) {
  try {
    console.log('🚀 Starting semantic search + AI pipeline...\n');
    
    // Step 1: Semantic search
    const searchResults = await semanticSearch(userQuery, filters);
    
    if (searchResults.results.length === 0) {
      return {
        userQuery,
        aiResponse: "I don't have any relevant conversation history to help answer your question. Could you provide more context?",
        contextUsed: [],
      };
    }
    
    // Step 2: Generate AI response
    const aiResult = await generateContextualResponse(userQuery, searchResults);
    
    console.log('\n🎉 Complete Response:');
    console.log('─'.repeat(50));
    console.log(`Query: ${aiResult.userQuery}`);
    console.log(`Response: ${aiResult.aiResponse}`);
    console.log('─'.repeat(50));
    
    return aiResult;
    
  } catch (error) {
    console.error('❌ Complete pipeline failed:', error);
    throw error;
  }
}

// Example usage and test cases
async function runTests() {
  try {
    console.log('🧪 Running semantic search tests...\n');
    
    // Test 1: Search for dress-related conversations
    await queryWithAI("How do customers feel about the dresses they ordered?");
    
    console.log('\n' + '='.repeat(80) + '\n');
    
    // Test 2: Search for appointment-related conversations
    await queryWithAI("What appointments are customers trying to schedule?");
    
    console.log('\n' + '='.repeat(80) + '\n');
    
    // Test 3: Search with sentiment filter
    await queryWithAI("Show me positive customer feedback", { sentiment: "POSITIVE" });
    
  } catch (error) {
    console.error('❌ Tests failed:', error);
  }
}

// Export functions for use in other modules
module.exports = {
  semanticSearch,
  generateContextualResponse,
  queryWithAI,
  runTests,
};

// Run tests if this file is executed directly
if (require.main === module) {
  runTests();
} 