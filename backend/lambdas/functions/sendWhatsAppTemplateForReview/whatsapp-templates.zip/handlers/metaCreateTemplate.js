// meta-create-template/handlers/metaCreateTemplate.js

const https = require("https");

// Helper function to make HTTPS requests
const makeHttpsRequest = (options, postData = null) =>
  new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        let json;
        try {
          json = JSON.parse(data);
        } catch (e) {
          return reject({ statusCode: 502, error: "Invalid JSON from API" });
        }
        if (res.statusCode < 200 || res.statusCode >= 300) {
          return reject({ statusCode: res.statusCode, error: json.error || "API error" });
        }
        return resolve(json);
      });
    });

    req.on("error", (err) => reject({ statusCode: 502, error: "Network error: " + err.message }));
    if (postData) {
      req.write(postData);
    }
    req.end();
  });

// Function to get WhatsApp credentials from Pipedream
const getWhatsAppCredentials = async (userId) => {
  const pipedreamUrl = `https://api.pipedream.com/v1/users/me/projects/${process.env.PIPEDREAM_PROJECT_ID}/accounts?app=whatsapp_business&external_user_id=${encodeURIComponent(userId)}`;
  
  const options = {
    hostname: "api.pipedream.com",
    port: 443,
    path: pipedreamUrl.replace('https://api.pipedream.com', ''),
    method: "GET",
    headers: {
      "Authorization": `Bearer ${process.env.PIPEDREAM_API_KEY}`,
      "Content-Type": "application/json",
    },
  };

  try {
    const response = await makeHttpsRequest(options);
    
    if (!response.data || response.data.length === 0) {
      throw new Error('No WhatsApp Business account connected');
    }

    const whatsappAccount = response.data[0];
    const businessAccountId = whatsappAccount.auth?.business_account_id;
    const accessToken = whatsappAccount.auth?.permanent_access_token || whatsappAccount.auth?.access_token;
    
    if (!businessAccountId || !accessToken) {
      throw new Error('Invalid WhatsApp credentials from Pipedream');
    }

    // Get phone number ID from business account
    const phoneOptions = {
      hostname: "graph.facebook.com",
      port: 443,
      path: `/v17.0/${businessAccountId}/phone_numbers?access_token=${accessToken}`,
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    };

    const phoneResponse = await makeHttpsRequest(phoneOptions);
    const phoneNumberId = phoneResponse.data?.[0]?.id;

    if (!phoneNumberId) {
      throw new Error('No phone numbers found for WhatsApp Business account');
    }

    return {
      token: accessToken,
      phoneNumberId: phoneNumberId,
      businessAccountId: businessAccountId
    };
  } catch (error) {
    console.error('Error getting WhatsApp credentials:', error);
    throw new Error(`Failed to get WhatsApp credentials: ${error.message}`);
  }
};

// Function to list WhatsApp message templates
const listTemplates = async (credentials) => {
  const options = {
    hostname: "graph.facebook.com",
    port: 443,
    path: `/v17.0/${credentials.phoneNumberId}/message_templates?access_token=${credentials.token}`,
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  };

  try {
    const result = await makeHttpsRequest(options);
    console.log('📋 Templates fetched successfully:', result.data?.length || 0, 'templates');
    return result;
  } catch (error) {
    console.error('❌ Error fetching templates:', error);
    throw error;
  }
};

// Function to create a WhatsApp message template
const createTemplate = async (credentials, templateData) => {
  const { name, language, category, components } = templateData;
  
  const graphPayload = { name, language, category, components };
  const postData = JSON.stringify(graphPayload);

  const options = {
    hostname: "graph.facebook.com",
    port: 443,
    path: `/v17.0/${credentials.phoneNumberId}/message_templates?access_token=${credentials.token}`,
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Content-Length": Buffer.byteLength(postData),
    },
  };

  try {
    const result = await makeHttpsRequest(options, postData);
    console.log('✅ Template created successfully:', result.id);
    return result;
  } catch (error) {
    console.error('❌ Error creating template:', error);
    throw error;
  }
};

// This is the Lambda entry point:
exports.handler = async (event) => {
  const method = event.requestContext?.http?.method;
  
  // Add CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  };

  // Handle OPTIONS for CORS preflight
  if (method === "OPTIONS") {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ""
    };
  }

  // Only allow GET and POST
  if (method !== "GET" && method !== "POST") {
    return {
      statusCode: 405,
      headers: { ...corsHeaders, Allow: "GET, POST, OPTIONS" },
      body: JSON.stringify({ error: "Method Not Allowed" }),
    };
  }

  // Extract userId from query parameters or body
  let userId;
  if (method === "GET") {
    userId = event.queryStringParameters?.userId;
  } else {
    try {
      const body = JSON.parse(event.body || "{}");
      userId = body.userId;
    } catch (parseErr) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Invalid JSON payload" }),
      };
    }
  }

  if (!userId) {
    return {
      statusCode: 400,
      headers: corsHeaders,
      body: JSON.stringify({ error: "userId is required" }),
    };
  }

  try {
    // Get WhatsApp credentials from Pipedream
    console.log(`📱 Getting WhatsApp credentials for user: ${userId}`);
    const credentials = await getWhatsAppCredentials(userId);
    console.log(`✅ WhatsApp credentials retrieved for user: ${userId}`);

    if (method === "GET") {
      // List templates
      console.log(`📋 Listing WhatsApp templates for user: ${userId}`);
      const result = await listTemplates(credentials);
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          success: true,
          templates: result.data || [],
          totalCount: result.data?.length || 0
        }),
      };
    } else {
      // Create template (POST)
      const body = JSON.parse(event.body);
      const { name, language, category, components } = body;
      
      if (
        typeof name !== "string" ||
        typeof language !== "string" ||
        typeof category !== "string" ||
        !Array.isArray(components)
      ) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({
            error: "Missing or invalid fields: name, language, category, components",
          }),
        };
      }

      console.log(`📝 Creating WhatsApp template for user: ${userId}`);
      const result = await createTemplate(credentials, { name, language, category, components });
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          success: true,
          message: "Template submitted for review",
          templateId: result.id,
        }),
      };
    }
  } catch (error) {
    console.error('❌ Lambda error:', error);
    const statusCode = error.statusCode || 500;
    const errorMsg = error.error || error.message || "Unknown error";
    
    return {
      statusCode,
      headers: corsHeaders,
      body: JSON.stringify({ error: errorMsg }),
    };
  }
};