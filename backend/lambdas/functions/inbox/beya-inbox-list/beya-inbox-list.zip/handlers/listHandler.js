// handlers/listHandler.js
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, ScanCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';

const REGION    = process.env.AWS_REGION;
const MSG_TABLE = process.env.MSG_TABLE;
const USER_MESSAGES_INDEX = 'User-Messages-Index'; // GSI name
const CORS      = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'OPTIONS,GET,POST',
  'Access-Control-Allow-Headers': 'Content-Type'
};

const ddb       = new DynamoDBClient({ region: REGION });
const docClient = DynamoDBDocumentClient.from(ddb);

export async function handler(event) {
  const method = event.requestContext?.http?.method;
  if (method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS };
  }
  if (method !== 'GET' && method !== 'POST') {
    return { statusCode: 405, headers: CORS, body: 'Method Not Allowed' };
  }
  if (!MSG_TABLE) {
    console.error('Missing MSG_TABLE env var');
    return { statusCode: 500, headers: CORS };
  }

  // Extract userId from request body (POST) or query parameters (GET)
  let userId = null;
  if (method === 'POST') {
    try {
      const body = JSON.parse(event.body || '{}');
      userId = body.userId;
    } catch {
      return { statusCode: 400, headers: CORS, body: 'Invalid JSON' };
    }
  } else {
    userId = event.queryStringParameters?.userId;
  }

  if (!userId) {
    return { 
      statusCode: 400, 
      headers: CORS, 
      body: JSON.stringify({ error: 'userId is required' })
    };
  }

  const threadId = event.pathParameters?.threadId;

  try {
    if (threadId) {
      // ——— RETURN ALL MESSAGES FOR THAT THREAD (USER-FILTERED) ———
      const resp = await docClient.send(new QueryCommand({
        TableName: MSG_TABLE,
        IndexName: USER_MESSAGES_INDEX,
        KeyConditionExpression: 'userId = :uid AND begins_with(ThreadIdTimestamp, :tid)',
        ExpressionAttributeValues: {
          ':uid': userId,
          ':tid': `${threadId}#`
        },
        ScanIndexForward: true // Sort by timestamp ascending
      }));

      // resp.Items is an array of your message objects (user-isolated)
      return {
        statusCode: 200,
        headers: CORS,
        body: JSON.stringify({ messages: resp.Items || [] })
      };
    } else {
      // ——— LIST ALL THREADS FOR THIS USER ———
      const resp = await docClient.send(new QueryCommand({
        TableName: MSG_TABLE,
        IndexName: USER_MESSAGES_INDEX,
        KeyConditionExpression: 'userId = :uid',
        ExpressionAttributeValues: {
          ':uid': userId
        }
      }));
      
      const items = resp.Items || [];
      // Extract unique ThreadIds from user's messages
      const threads = Array.from(new Set(items.map(i => i.ThreadId)));
      
      return {
        statusCode: 200,
        headers: CORS,
        body: JSON.stringify({ threads })
      };
    }
  } catch (err) {
    console.error('❌ listHandler error', err);
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ error: 'Internal Server Error' })
    };
  }
}