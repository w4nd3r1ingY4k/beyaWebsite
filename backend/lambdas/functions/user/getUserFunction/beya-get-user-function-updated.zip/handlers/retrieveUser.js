// handlers/getUser.js

const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  GetCommand
} = require("@aws-sdk/lib-dynamodb");
const { ConnectionsService } = require("../lib/connections-service");

// Initialize DocumentClient
const ddbClient = new DynamoDBClient({});
const ddb = DynamoDBDocumentClient.from(ddbClient);

const USERS_TABLE = process.env.USERS_TABLE; // ensure this is set in your Lambda env

exports.handler = async (event) => {
  try {
    // Extract the userId from the HTTP path: GET /users/{userId}
    const userId = event.pathParameters && event.pathParameters.userId;
    if (!userId) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Missing path parameter 'userId'" })
      };
    }

    // Check if this is a connections request: GET /users/{userId}/connections
    const pathSegments = event.requestContext?.http?.path?.split('/') || [];
    const isConnectionsRequest = pathSegments.includes('connections');

    if (isConnectionsRequest) {
      // Handle connections request
      return await handleConnectionsRequest(userId);
    } else {
      // Handle regular user data request
      return await handleUserRequest(userId);
    }
  } catch (err) {
    console.error("Error in user handler:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};

async function handleUserRequest(userId) {
  // Fetch the item from DynamoDB
  const { Item } = await ddb.send(new GetCommand({
    TableName: USERS_TABLE,
    Key: { userId }
  }));

  // If no item found, return 404
  if (!Item) {
    return {
      statusCode: 404,
      body: JSON.stringify({ message: "User not found" })
    };
  }

  // Return the full metadata
  return {
    statusCode: 200,
    body: JSON.stringify(Item)
  };
}

async function handleConnectionsRequest(userId) {
  try {
    // Get user data first to verify user exists
    const { Item: user } = await ddb.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "User not found" })
      };
    }

    // Use ConnectionsService to fetch real connected accounts from Pipedream
    const connectionsService = new ConnectionsService();
    const connectionsData = await connectionsService.getAllConnectedAccounts(userId);

    return {
      statusCode: 200,
      body: JSON.stringify({
        userId,
        ...connectionsData
      })
    };
  } catch (err) {
    console.error("Error fetching user connections:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        message: "Failed to fetch connections",
        error: err.message 
      })
    };
  }
}