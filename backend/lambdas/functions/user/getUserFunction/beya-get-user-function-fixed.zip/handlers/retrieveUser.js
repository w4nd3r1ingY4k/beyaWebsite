// handlers/getUser.js

const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  GetCommand
} = require("@aws-sdk/lib-dynamodb");
const { ConnectionsService } = require("../lib/connections-service");

// Initialize DocumentClient
const ddbClient = new DynamoDBClient({});
const ddb = DynamoDBDocumentClient.from(ddbClient);

const USERS_TABLE = process.env.USERS_TABLE; // ensure this is set in your Lambda env

exports.handler = async (event) => {
  try {
    console.log("Event received:", JSON.stringify(event, null, 2));
    
    // Handle both Function URL and API Gateway event formats
    let userId, path;
    
    if (event.rawPath) {
      // Function URL format
      path = event.rawPath;
      const pathSegments = path.split('/').filter(Boolean);
      
      // Expected format: /users/{userId} or /users/{userId}/connections
      if (pathSegments.length >= 2 && pathSegments[0] === 'users') {
        userId = pathSegments[1];
      }
    } else if (event.pathParameters) {
      // API Gateway format
      userId = event.pathParameters.userId;
      path = event.requestContext?.http?.path || event.rawPath;
    }
    
    console.log("Extracted userId:", userId);
    console.log("Extracted path:", path);
    
    if (!userId) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: "Missing path parameter 'userId'" })
      };
    }

    // Check if this is a connections request
    const isConnectionsRequest = path && path.includes('/connections');
    console.log("Is connections request:", isConnectionsRequest);

    if (isConnectionsRequest) {
      // Handle connections request
      return await handleConnectionsRequest(userId);
    } else {
      // Handle regular user data request
      return await handleUserRequest(userId);
    }
  } catch (err) {
    console.error("Error in user handler:", err);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message: "Internal server error" })
    };
  }
};

async function handleUserRequest(userId) {
  // Fetch the item from DynamoDB
  const { Item } = await ddb.send(new GetCommand({
    TableName: USERS_TABLE,
    Key: { userId }
  }));

  // If no item found, return 404
  if (!Item) {
    return {
      statusCode: 404,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message: "User not found" })
    };
  }

  // Return the full metadata
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(Item)
  };
}

async function handleConnectionsRequest(userId) {
  try {
    console.log("Handling connections request for userId:", userId);
    
    // Get user data first to verify user exists
    const { Item: user } = await ddb.send(new GetCommand({
      TableName: USERS_TABLE,
      Key: { userId }
    }));

    if (!user) {
      return {
        statusCode: 404,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: "User not found" })
      };
    }

    console.log("User found, fetching connections...");

    // Use ConnectionsService to fetch real connected accounts from Pipedream
    const connectionsService = new ConnectionsService();
    const connectionsData = await connectionsService.getAllConnectedAccounts(userId);

    console.log("Connections data fetched successfully");

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        userId,
        ...connectionsData
      })
    };
  } catch (err) {
    console.error("Error fetching user connections:", err);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ 
        message: "Failed to fetch connections",
        error: err.message 
      })
    };
  }
}